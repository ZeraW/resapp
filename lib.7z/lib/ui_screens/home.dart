import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

import 'package:provider/provider.dart';
import 'package:resapp/models/db_model.dart';
import 'package:resapp/server/auth.dart';
import 'package:resapp/utils/dimensions.dart';
import 'package:resapp/utils/utils.dart';

class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  Widget build(BuildContext context) {
    DocumentSnapshot snapshot = Provider.of<DocumentSnapshot>(context);

    if (snapshot != null) {
      UserModel user = UserModel.fromJson(snapshot.data());

      /*if(user!=null && user.type=='admin'){
        _children.add({'Admin Panel': AdminScreen()});
        _bottomNavigation.add(BottomNavigationBarItem(
            icon: Icon(Icons.whatshot), label: _children[4].keys.first));
      }*/
    }

    return Scaffold(
      appBar: new AppBar(
          centerTitle: true,
          elevation: 0.0,
          automaticallyImplyLeading: false,
          backgroundColor: Uti().mainColor,
          title: Text(
            'Home',
            style: TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.bold,
                fontSize: Dimensions.getWidth(5)),
          )),
      body: Center(
        child: ElevatedButton(
          onPressed: () async{
            await AuthService().signOut();
          },
          child: Text('SignOut'),
        ),
      ),
    );
  }
}
