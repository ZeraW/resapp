import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:resapp/server/auth_manage.dart';
import 'package:resapp/server/database_api.dart';
import 'models/db_model.dart';
import 'ui_screens/choose_login_type.dart';
import 'ui_screens/home.dart';

class Wrapper extends StatefulWidget {
  static String UID = '';

  @override
  _WrapperState createState() => _WrapperState();
}

class _WrapperState extends State<Wrapper> {
  @override
  Widget build(BuildContext context) {
    final user = Provider.of<User>(context);
    // return either the Home or Authenticate widget
    if (user == null) {
      return ChangeNotifierProvider(
          create: (context) => AuthManage(), child: RootScreen());
    } else {
      Wrapper.UID = user.uid;
      return MultiProvider(providers: [
        StreamProvider<List<CityModel>>.value(
            value: DatabaseService().getLiveCities),
        StreamProvider<DocumentSnapshot>.value(
            value: DatabaseService().getUserById)
      ], child: HomeScreen());
    }
  }
}
